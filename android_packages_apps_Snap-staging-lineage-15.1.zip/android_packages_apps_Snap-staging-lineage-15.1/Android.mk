LOCAL_PATH:= $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE_TAGS := optional

LOCAL_STATIC_JAVA_LIBRARIES := android-support-v13
LOCAL_STATIC_JAVA_LIBRARIES += android-support-v4
LOCAL_STATIC_JAVA_LIBRARIES += xmp_toolkit
LOCAL_STATIC_JAVA_LIBRARIES += zxing-core

LOCAL_SRC_FILES := $(call all-java-files-under, src)
LOCAL_SRC_FILES += $(call all-java-files-under, src_pd)
LOCAL_SRC_FILES += $(call all-java-files-under, src_pd_gcam)
LOCAL_SRC_FILES += $(call all-java-files-under, src_wrapper)
LOCAL_SRC_FILES += $(call all-java-files-under, quickReader/src)
LOCAL_SRC_FILES += $(call all-renderscript-files-under, rs)

LOCAL_RESOURCE_DIR += $(LOCAL_PATH)/res
LOCAL_RESOURCE_DIR += $(LOCAL_PATH)/quickReader/res

include $(LOCAL_PATH)/version.mk
LOCAL_AAPT_FLAGS := \
        --auto-add-overlay \
        --version-name "$(version_name_package)" \
        --version-code $(version_code_package) \
        --extra-packages me.dm7.barcodescanner.core \
        --extra-packages me.dm7.barcodescanner.zxing

LOCAL_STATIC_JAVA_AAR_LIBRARIES += \
    qreader-core \
    qreader-zxing

LOCAL_JAVA_LIBRARIES := org.lineageos.platform.internal

LOCAL_PACKAGE_NAME := Snap
LOCAL_PRIVILEGED_MODULE := true

LOCAL_AAPT_FLAGS += --rename-manifest-package org.lineageos.snap

#LOCAL_SDK_VERSION := current
LOCAL_RENDERSCRIPT_TARGET_API := 23
LOCAL_JACK_ENABLED := disabled

LOCAL_OVERRIDES_PACKAGES := Camera2

LOCAL_PROGUARD_FLAG_FILES := proguard.flags

# Always bundle Snap's JNI libraries into the APK. During testing Snap may be
# installed as a regular app under /data/app; Android 8+ linker namespaces do
# not allow such an app to load these private libraries from /system/lib[64].
# Keeping the APK copies makes System.loadLibrary("jni_snapimageutil") resolve
# from the app's own nativeLibraryDir instead of the blocked system path.
LOCAL_JNI_SHARED_LIBRARIES := libjni_snapmosaic libjni_snaptinyplanet libjni_snapimageutil

# Also retain the system copies for ROM builds that install Snap as a privileged
# system app. Standalone/data-app installs use the libraries packaged above.
LOCAL_REQUIRED_MODULES := libjni_snapmosaic libjni_snaptinyplanet libjni_snapimageutil
include $(BUILD_PACKAGE)

include $(CLEAR_VARS)

LOCAL_PREBUILT_STATIC_JAVA_LIBRARIES += \
    qreader-core:quickReader/libs/core-1.9.3.aar \
    qreader-zxing:quickReader/libs/zxing-1.9.3.aar \
    zxing-core:quickReader/libs/zxing-core-g-2.3.1.jar

include $(BUILD_MULTI_PREBUILT)

include $(call all-makefiles-under, $(LOCAL_PATH))
